import styled from 'styled-components';

export const Wrapper = styled.div`
	// border: 1px solid lightgrey;
`;

export const ListWrapper = styled.div`
	overflow: hidden;
`;

